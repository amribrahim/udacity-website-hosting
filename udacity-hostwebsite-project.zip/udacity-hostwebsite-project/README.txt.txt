webiste url: https://d2k161xzbqth3v.cloudfront.net/

s3 url: http://udacitys3-project.s3-website-us-east-1.amazonaws.com/